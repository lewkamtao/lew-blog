import{L as e}from"./entry.fdcc51fb.js";const s=()=>e("menuActive",()=>""),r=()=>e("seriesActive",()=>0),u=()=>e("blog",()=>({seriesTotal:0,articleTotal:0}));export{r as a,u as b,s as u};
