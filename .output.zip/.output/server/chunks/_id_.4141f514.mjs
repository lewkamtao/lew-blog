import { _ as _export_sfc, u as useNuxtApp, a as useRoute, b as useHead, c as __nuxt_component_0$1 } from './server.mjs';
import { ref, withAsyncContext, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderList, ssrRenderComponent } from 'vue/server-renderer';
import MdEditor from 'md-editor-v3';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@vueuse/core';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const dateFormat = (date) => {
  var timestamp = new Date(date) / 1e3;
  function zeroize(num) {
    return (String(num).length == 1 ? "0" : "") + num;
  }
  var curTimestamp = parseInt(JSON.stringify(new Date().getTime() / 1e3));
  var timestampDiff = curTimestamp - timestamp;
  var curDate = new Date(curTimestamp * 1e3);
  var tmDate = new Date(timestamp * 1e3);
  var Y = tmDate.getFullYear(), m = tmDate.getMonth() + 1, d = tmDate.getDate();
  var H = tmDate.getHours(), i = tmDate.getMinutes();
  tmDate.getSeconds();
  if (timestampDiff < 60) {
    return "\u521A\u521A";
  } else if (timestampDiff < 3600) {
    return Math.floor(timestampDiff / 60) + " \u5206\u949F\u524D";
  } else if (curDate.getFullYear() == Y && curDate.getMonth() + 1 == m && curDate.getDate() == d) {
    return "\u4ECA\u5929 " + zeroize(H) + ":" + zeroize(i);
  } else {
    var newDate = new Date((curTimestamp - 86400) * 1e3);
    if (newDate.getFullYear() == Y && newDate.getMonth() + 1 == m && newDate.getDate() == d) {
      return "\u6628\u5929 " + zeroize(H) + ":" + zeroize(i);
    } else if (curDate.getFullYear() == Y) {
      return "\u4ECA\u5E74 " + zeroize(m) + "\u6708" + zeroize(d) + "\u65E5 " + zeroize(H) + ":" + zeroize(i);
    } else {
      return Y + "\u5E74" + zeroize(m) + "\u6708" + zeroize(d) + "\u65E5 " + zeroize(H) + ":" + zeroize(i);
    }
  }
};
const _sfc_main = {
  __name: "[id]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { $api } = useNuxtApp();
    const route = useRoute();
    const id = route.params.id;
    let article = ref({});
    const { data } = ([__temp, __restore] = withAsyncContext(() => $api.get("/blog/app/article/" + id)), __temp = await __temp, __restore(), __temp);
    article.value = data;
    useHead({
      title: article.value.title
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Comment = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "article-wrapper" }, _attrs))} data-v-7119276f><div class="article-main" data-v-7119276f><div class="article-body" data-v-7119276f><div class="h1" data-v-7119276f>${ssrInterpolate(unref(article).title)}</div><div class="info" data-v-7119276f><div class="left" data-v-7119276f><div class="item" data-v-7119276f> \u7CFB\u5217\uFF1A<span class="vs-tag" data-v-7119276f>${ssrInterpolate(unref(article).series.title)}</span></div><div class="item" data-v-7119276f> \u6807\u7B7E\uFF1A <div class="tags" data-v-7119276f><!--[-->`);
      ssrRenderList(unref(article).tags, (item, index) => {
        _push(`<span class="vs-tag" data-v-7119276f>${ssrInterpolate(item.title)}</span>`);
      });
      _push(`<!--]--></div></div></div><div class="right" data-v-7119276f><div class="item" data-v-7119276f>\u6D4F\u89C8\u91CF\uFF1A${ssrInterpolate(unref(article).view_num || "\u6682\u65E0")}</div><div class="item" data-v-7119276f> \u6700\u540E\u4FEE\u6539\u65F6\u95F4\uFF1A${ssrInterpolate(unref(dateFormat)(unref(article).updated_at))}</div></div></div>`);
      _push(ssrRenderComponent(unref(MdEditor), {
        modelValue: unref(article).content,
        "onUpdate:modelValue": ($event) => unref(article).content = $event,
        "preview-only": "",
        theme: "dark"
      }, null, _parent));
      _push(`</div></div>`);
      _push(ssrRenderComponent(_component_Comment, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/article/[id].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _id_ = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-7119276f"]]);

export { _id_ as default };
//# sourceMappingURL=_id_.4141f514.mjs.map
