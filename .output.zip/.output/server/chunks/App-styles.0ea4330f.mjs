import { A as App_vue_vue_type_style_index_0_lang, a as App_vue_vue_type_style_index_1_lang } from './styles.mjs';

const AppStyles_0ea4330f = [App_vue_vue_type_style_index_0_lang, App_vue_vue_type_style_index_1_lang];

export { AppStyles_0ea4330f as default };
//# sourceMappingURL=App-styles.0ea4330f.mjs.map
