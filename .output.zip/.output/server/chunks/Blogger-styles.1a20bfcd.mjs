const Blogger_vue_vue_type_style_index_0_scoped_8070db53_lang = ".blogger[data-v-8070db53]{box-sizing:border-box;padding:20px}.blogger .avatar[data-v-8070db53]{border-radius:50%;height:120px;width:120px}.blogger .nickname[data-v-8070db53]{align-items:center;display:flex;font-size:16px;font-weight:bolder;gap:2px}.blogger .nickname .codicon[data-v-8070db53]{color:var(--blue06);font-size:20px}.blogger .description[data-v-8070db53]{border-bottom:1px solid var(--base15);color:var(--base10);padding:10px 0;white-space:pre-wrap}.blogger .info[data-v-8070db53]{display:flex;flex-direction:column;gap:5px;padding:10px 0}.blogger .info .value[data-v-8070db53]{color:var(--blue06)}";

const BloggerStyles_1a20bfcd = [Blogger_vue_vue_type_style_index_0_scoped_8070db53_lang];

export { BloggerStyles_1a20bfcd as default };
//# sourceMappingURL=Blogger-styles.1a20bfcd.mjs.map
