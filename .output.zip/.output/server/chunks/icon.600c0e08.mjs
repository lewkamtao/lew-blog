import { _ as _export_sfc, u as useNuxtApp } from './server.mjs';
import { useSSRContext, defineComponent, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderList, ssrRenderClass, ssrInterpolate } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@vueuse/core';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "icon",
  __ssrInlineRender: true,
  setup(__props) {
    useNuxtApp();
    const options = [{
      label: "JavaScript",
      value: "javascript"
    }, {
      label: "react",
      value: "react"
    }, {
      label: "vue",
      value: "vue"
    }, {
      label: "go",
      value: "go2"
    }, {
      label: "html",
      value: "html"
    }, {
      label: "css",
      value: "css"
    }, {
      label: "Java",
      value: "java"
    }, {
      label: "json",
      value: "json"
    }, {
      label: "typescript",
      value: "typescript"
    }, {
      label: "docker",
      value: "docker"
    }, {
      label: "config",
      value: "config"
    }, {
      label: "c",
      value: "c"
    }, {
      label: "php",
      value: "php"
    }, {
      label: "markdown",
      value: "markdown"
    }, {
      label: "lua",
      value: "lua"
    }, {
      label: "python",
      value: "python"
    }, {
      label: "SQL",
      value: "db"
    }, {
      label: "sass",
      value: "sass"
    }];
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "lew" }, _attrs))} data-v-db9df8b2><!--[-->`);
      ssrRenderList(options, (item, index) => {
        _push(`<div class="item" data-v-db9df8b2><i class="${ssrRenderClass(["icon-" + item.value, "icon-seti"])}" data-v-db9df8b2></i><span data-v-db9df8b2>${ssrInterpolate(item.label)}</span></div>`);
      });
      _push(`<!--]--></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/icon.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const icon = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-db9df8b2"]]);

export { icon as default };
//# sourceMappingURL=icon.600c0e08.mjs.map
