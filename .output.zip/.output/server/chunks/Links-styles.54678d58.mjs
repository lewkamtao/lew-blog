const Links_vue_vue_type_style_index_0_scoped_5f1fc0ad_lang = ".links .title[data-v-5f1fc0ad]{background:var(--base19);padding:5px 14px;position:sticky;top:0;width:100%;z-index:99}.links .list[data-v-5f1fc0ad]{display:flex;flex-direction:column}.links .list .item[data-v-5f1fc0ad]{align-items:center;color:var(--base03);cursor:pointer;display:flex;gap:10px;padding:7px 14px}.links .list .item .avatar[data-v-5f1fc0ad]{height:50px;width:50px}.links .list .item .info[data-v-5f1fc0ad]{display:flex;flex-direction:column;white-space:nowrap}.links .list .item .info .blog[data-v-5f1fc0ad]{font-size:14px;font-weight:700}.links .list .item .info .blog[data-v-5f1fc0ad],.links .list .item .info .url[data-v-5f1fc0ad]{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;width:210px}.links .list .item .info .url[data-v-5f1fc0ad]{opacity:.6}.links .list .item .info .nickname[data-v-5f1fc0ad]{font-size:14px;font-weight:700}.links .list .item[data-v-5f1fc0ad]:hover{background-color:var(--base14)}";

const LinksStyles_54678d58 = [Links_vue_vue_type_style_index_0_scoped_5f1fc0ad_lang];

export { LinksStyles_54678d58 as default };
//# sourceMappingURL=Links-styles.54678d58.mjs.map
