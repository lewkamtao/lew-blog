import { e as useState } from './server.mjs';

const useMenuActive = () => {
  return useState("menuActive", () => "");
};
const useSeriesActive = () => {
  return useState("seriesActive", () => 0);
};
const useBlog = () => {
  return useState("blog", () => {
    return {
      seriesTotal: 0,
      articleTotal: 0
    };
  });
};

export { useSeriesActive as a, useBlog as b, useMenuActive as u };
//# sourceMappingURL=index.5652b549.mjs.map
