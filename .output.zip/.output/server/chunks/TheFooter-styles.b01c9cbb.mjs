const TheFooter_vue_vue_type_style_index_0_scoped_f6cd5e4e_lang = ".footer[data-v-f6cd5e4e]{align-items:center;background-color:var(--blue06);color:var(--base02);font-size:13px;height:22px;justify-content:space-between;padding:0 15px;white-space:nowrap}.footer[data-v-f6cd5e4e],.footer div[data-v-f6cd5e4e]{display:flex;gap:20px}.footer a[data-v-f6cd5e4e]{color:#fff}";

const TheFooterStyles_b01c9cbb = [TheFooter_vue_vue_type_style_index_0_scoped_f6cd5e4e_lang];

export { TheFooterStyles_b01c9cbb as default };
//# sourceMappingURL=TheFooter-styles.b01c9cbb.mjs.map
