const Setting_vue_vue_type_style_index_0_scoped_9fadec2e_lang = ".setting .main[data-v-9fadec2e],.setting .title[data-v-9fadec2e]{padding:5px 10px}.setting .main[data-v-9fadec2e]{align-items:center;display:flex}";

const SettingStyles_6e79fc36 = [Setting_vue_vue_type_style_index_0_scoped_9fadec2e_lang];

export { SettingStyles_6e79fc36 as default };
//# sourceMappingURL=Setting-styles.6e79fc36.mjs.map
