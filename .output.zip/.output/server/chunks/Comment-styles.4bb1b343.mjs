import { C as Comment_vue_vue_type_style_index_0_scoped_61dde502_lang } from './styles.mjs';

const CommentStyles_4bb1b343 = [Comment_vue_vue_type_style_index_0_scoped_61dde502_lang];

export { CommentStyles_4bb1b343 as default };
//# sourceMappingURL=Comment-styles.4bb1b343.mjs.map
