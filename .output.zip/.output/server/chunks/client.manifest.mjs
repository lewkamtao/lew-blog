const client_manifest = {
  "assets/styles/seti/_fonts/seti/seti.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "seti.0268d859.woff",
    "src": "assets/styles/seti/_fonts/seti/seti.woff"
  },
  "assets/fonts/codicon.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "codicon.15437a6c.ttf",
    "src": "assets/fonts/codicon.ttf"
  },
  "node_modules/nuxt/dist/app/entry.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "entry.fdcc51fb.js",
    "src": "node_modules/nuxt/dist/app/entry.mjs",
    "isEntry": true,
    "dynamicImports": [
      "virtual:nuxt:C:/Users/div/Documents/GitHub/lew-blog/.nuxt/error-component.mjs",
      "layouts/default.vue",
      "node_modules/nuxt/dist/app/entry.mjs-css"
    ],
    "css": [],
    "assets": [
      "seti.0268d859.woff",
      "codicon.15437a6c.ttf"
    ]
  },
  "entry.f3e9fe54.css": {
    "file": "entry.f3e9fe54.css",
    "resourceType": "style"
  },
  "seti.0268d859.woff": {
    "file": "seti.0268d859.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "codicon.15437a6c.ttf": {
    "file": "codicon.15437a6c.ttf",
    "resourceType": "font",
    "mimeType": "font/ttf"
  },
  "virtual:nuxt:C:/Users/div/Documents/GitHub/lew-blog/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "error-component.f8d25992.js",
    "src": "virtual:nuxt:C:/Users/div/Documents/GitHub/lew-blog/.nuxt/error-component.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ]
  },
  "pages/article/[id].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_id_.289dfbd2.js",
    "src": "pages/article/[id].vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_index.e41db10c.js",
      "__plugin-vue_export-helper.a1a6add7.js"
    ],
    "css": []
  },
  "_id_.c2460c94.css": {
    "file": "_id_.c2460c94.css",
    "resourceType": "style"
  },
  "__plugin-vue_export-helper.a1a6add7.js": {
    "resourceType": "script",
    "module": true,
    "file": "_plugin-vue_export-helper.a1a6add7.js"
  },
  "_index.e41db10c.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.e41db10c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/icon.vue": {
    "resourceType": "script",
    "module": true,
    "file": "icon.399a2764.js",
    "src": "pages/icon.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "__plugin-vue_export-helper.a1a6add7.js"
    ],
    "css": []
  },
  "icon.806c0053.css": {
    "file": "icon.806c0053.css",
    "resourceType": "style"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.aca6cc8b.js",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_index.82f4b8b3.js",
      "__plugin-vue_export-helper.a1a6add7.js"
    ],
    "css": []
  },
  "index.e41e80c7.css": {
    "file": "index.e41e80c7.css",
    "resourceType": "style"
  },
  "_index.82f4b8b3.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.82f4b8b3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "file": "default.59b64945.js",
    "src": "layouts/default.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_index.82f4b8b3.js",
      "__plugin-vue_export-helper.a1a6add7.js",
      "_index.e41db10c.js"
    ],
    "css": []
  },
  "default.4e6e9fa5.css": {
    "file": "default.4e6e9fa5.css",
    "resourceType": "style"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "file": "error-404.20941165.js",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "__plugin-vue_export-helper.a1a6add7.js"
    ],
    "css": []
  },
  "error-404.18ced855.css": {
    "file": "error-404.18ced855.css",
    "resourceType": "style"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "file": "error-500.d6a6ec30.js",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "__plugin-vue_export-helper.a1a6add7.js"
    ],
    "css": []
  },
  "error-500.e60962de.css": {
    "file": "error-500.e60962de.css",
    "resourceType": "style"
  },
  "pages/index.css": {
    "resourceType": "style",
    "file": "index.e41e80c7.css",
    "src": "pages/index.css"
  },
  "pages/icon.css": {
    "resourceType": "style",
    "file": "icon.806c0053.css",
    "src": "pages/icon.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.18ced855.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.e60962de.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "layouts/default.css": {
    "resourceType": "style",
    "file": "default.4e6e9fa5.css",
    "src": "layouts/default.css"
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.f3e9fe54.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "pages/article/[id].css": {
    "resourceType": "style",
    "file": "_id_.c2460c94.css",
    "src": "pages/article/[id].css"
  },
  "node_modules/nuxt/dist/app/entry.mjs-css": {
    "file": "",
    "css": [
      "entry.f3e9fe54.css"
    ]
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
