const User_vue_vue_type_style_index_0_scoped_341d46d9_lang = ".blogger[data-v-341d46d9]{box-sizing:border-box;padding:20px}.blogger .avatar[data-v-341d46d9]{border-radius:50%;height:120px;width:120px}.blogger .nickname[data-v-341d46d9]{align-items:center;display:flex;font-size:16px;font-weight:bolder;gap:2px}.blogger .nickname .codicon[data-v-341d46d9]{color:var(--blue06);font-size:20px}.blogger .description[data-v-341d46d9]{border-bottom:1px solid var(--base15);color:var(--base10);padding:10px 0;white-space:pre-wrap}.blogger .info[data-v-341d46d9]{display:flex;flex-direction:column;gap:5px;padding:10px 0}.blogger .info .value[data-v-341d46d9]{color:var(--blue06)}";

const UserStyles_c7757220 = [User_vue_vue_type_style_index_0_scoped_341d46d9_lang];

export { UserStyles_c7757220 as default };
//# sourceMappingURL=User-styles.c7757220.mjs.map
