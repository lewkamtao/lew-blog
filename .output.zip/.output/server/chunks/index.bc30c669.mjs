import { _ as _export_sfc, u as useNuxtApp, d as useRouter, b as useHead } from './server.mjs';
import { useSSRContext, defineComponent, ref, mergeProps, unref } from 'vue';
import { u as useMenuActive, a as useSeriesActive } from './index.5652b549.mjs';
import { ssrRenderAttrs, ssrRenderList, ssrInterpolate } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@vueuse/core';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const { $api } = useNuxtApp();
    let articles = ref([]);
    let series = ref([]);
    let articlesTotal = ref(0);
    const getArticle = async () => {
      const { data, total } = await $api.get("/blog/app/article/list?limit=20");
      articles.value = data;
      articlesTotal.value = total;
    };
    const getSeries = async () => {
      const { data } = await $api.get("/blog/app/series/list?limit=100");
      series.value = data;
    };
    getArticle();
    getSeries();
    const isMore = ref(false);
    useMenuActive();
    useSeriesActive();
    useRouter();
    useHead({
      title: "Visual Studio Blog"
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "lew" }, _attrs))} data-v-be77f07e><div class="header" data-v-be77f07e><div class="title" data-v-be77f07e>Visual Studio Blog</div><div class="sub-title" data-v-be77f07e>\u4E2A\u4EBA\u535A\u5BA2</div></div><div class="main" data-v-be77f07e><div class="left" data-v-be77f07e><div class="part" data-v-be77f07e><div class="title" data-v-be77f07e>\u542F\u52A8</div><div class="list start" data-v-be77f07e><div class="item" data-v-be77f07e><i class="codicon codicon-account" data-v-be77f07e></i> \u5173\u4E8E\u6211 </div><div class="item" data-v-be77f07e><i class="codicon codicon-github" data-v-be77f07e></i> Github </div><div class="item" data-v-be77f07e><i class="codicon codicon-source-control" data-v-be77f07e></i> \u53CB\u60C5\u94FE\u63A5 </div></div></div><div class="part" data-v-be77f07e><div class="title" data-v-be77f07e>\u6700\u8FD1\u6587\u7AE0</div><div class="list" data-v-be77f07e><!--[-->`);
      ssrRenderList(unref(articles), (item, index2) => {
        _push(`<div class="item" data-v-be77f07e>${ssrInterpolate(item.title)}</div>`);
      });
      _push(`<!--]-->`);
      if (!isMore.value) {
        _push(`<div class="item" data-v-be77f07e>\u66F4\u591A...</div>`);
      } else {
        _push(`<div class="item" data-v-be77f07e> \u5171 ${ssrInterpolate(unref(articlesTotal))} \u7BC7\u6587\u7AE0\uFF0C\u6B64\u5904\u4EC5\u5C55\u793A\u6700\u65B0 50 \u7BC7\u3002 </div>`);
      }
      _push(`</div></div></div><div class="right" data-v-be77f07e><div class="part" data-v-be77f07e><div class="title" data-v-be77f07e>\u7CFB\u5217</div><div class="list series" data-v-be77f07e><!--[-->`);
      ssrRenderList(unref(series), (item, index2) => {
        _push(`<div class="item" data-v-be77f07e>${ssrInterpolate(item.title)}</div>`);
      });
      _push(`<!--]--></div></div></div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-be77f07e"]]);

export { index as default };
//# sourceMappingURL=index.bc30c669.mjs.map
