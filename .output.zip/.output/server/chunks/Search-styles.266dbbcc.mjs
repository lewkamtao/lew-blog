const Search_vue_vue_type_style_index_0_scoped_ccdffadc_lang = ".search[data-v-ccdffadc]{padding:10px}.search .vs-input[data-v-ccdffadc]{margin:5px 0}.search .list[data-v-ccdffadc]{margin-top:10px}.search .total[data-v-ccdffadc]{color:var(--base10)}.search .article-item .item-box[data-v-ccdffadc]{align-items:center;cursor:pointer;display:flex;height:28px;padding:0 8px}.search .article-item .item-box .icon-box[data-v-ccdffadc]{align-items:center;display:flex;height:24px;justify-content:center;width:24px}.search .article-item .item-box .title[data-v-ccdffadc]{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;width:calc(100% - 50px)}.search .article-item .item-box[data-v-ccdffadc]:hover{background-color:var(--base17)}.search .article-item .not-box[data-v-ccdffadc]{opacity:.45;padding-left:36px}.search .article-item .cur-item[data-v-ccdffadc],.search .article-item .cur-item[data-v-ccdffadc]:hover{background-color:var(--base15)}";

const SearchStyles_266dbbcc = [Search_vue_vue_type_style_index_0_scoped_ccdffadc_lang];

export { SearchStyles_266dbbcc as default };
//# sourceMappingURL=Search-styles.266dbbcc.mjs.map
