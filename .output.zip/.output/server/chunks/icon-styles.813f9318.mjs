const icon_vue_vue_type_style_index_0_scoped_db9df8b2_lang = ".lew[data-v-db9df8b2]{flex-wrap:wrap;gap:10px}.lew[data-v-db9df8b2],.lew .item[data-v-db9df8b2]{display:flex;justify-content:center}.lew .item[data-v-db9df8b2]{align-items:center;flex-direction:column}.lew .item i[data-v-db9df8b2]{font-size:50px;padding:10px}";

const iconStyles_813f9318 = [icon_vue_vue_type_style_index_0_scoped_db9df8b2_lang];

export { iconStyles_813f9318 as default };
//# sourceMappingURL=icon-styles.813f9318.mjs.map
