const Series_vue_vue_type_style_index_0_scoped_75fad51b_lang = "";

const SeriesStyles_fc679f9e = [Series_vue_vue_type_style_index_0_scoped_75fad51b_lang];

export { SeriesStyles_fc679f9e as default };
//# sourceMappingURL=Series-styles.fc679f9e.mjs.map
