const default_vue_vue_type_style_index_0_scoped_95b6d713_lang = ".lew[data-v-95b6d713]{display:flex;flex-direction:column}.lew .main[data-v-95b6d713]{display:flex;height:calc(100vh - 22px)}.lew .main .wrapper[data-v-95b6d713]{height:100%;overflow-y:auto;width:calc(100% - 360px)}";

const defaultStyles_59962a85 = [default_vue_vue_type_style_index_0_scoped_95b6d713_lang];

export { defaultStyles_59962a85 as default };
//# sourceMappingURL=default-styles.59962a85.mjs.map
