import { _ as _export_sfc, u as useNuxtApp, a as useRoute, d as useRouter, f as __nuxt_component_0$2$1 } from './server.mjs';
import { useSSRContext, defineComponent, ref, withAsyncContext, watch, mergeProps, unref, withCtx, createVNode, toDisplayString, nextTick } from 'vue';
import { b as useBlog, a as useSeriesActive, u as useMenuActive } from './index.5652b549.mjs';
import { ssrRenderAttrs, ssrRenderList, ssrRenderClass, ssrRenderAttr, ssrInterpolate, ssrRenderStyle, ssrRenderComponent, ssrRenderSlot } from 'vue/server-renderer';
import dayjs from 'dayjs';
import { useNavigatorLanguage } from '@vueuse/core';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main$9 = /* @__PURE__ */ defineComponent({
  __name: "MenuList",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { $api } = useNuxtApp();
    const route = useRoute();
    useRouter();
    const series = ref([]);
    const curId = ref();
    series.value = ([__temp, __restore] = withAsyncContext(() => $api.get("/blog/app/series/list")), __temp = await __temp, __restore(), __temp).data;
    let seriestotal = ([__temp, __restore] = withAsyncContext(() => $api.get("/blog/app/series/list")), __temp = await __temp, __restore(), __temp).total;
    let articleTotal = ([__temp, __restore] = withAsyncContext(() => $api.get("/blog/app/article/list")), __temp = await __temp, __restore(), __temp).total;
    let blog = useBlog();
    blog.value = {
      seriesTotal: seriestotal,
      articleTotal
    };
    watch(route, (v) => {
      const id = route.params.id;
      curId.value = id;
    });
    const seriesActive = useSeriesActive();
    watch(seriesActive, (v) => {
      series.value = series.value.map((e) => {
        return {
          ...e,
          isShow: false
        };
      });
      let index = series.value.findIndex((e) => e.id == v);
      series.value[index].isShow = true;
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "series-list" }, _attrs))} data-v-1a06265f><div class="item-box active" data-v-1a06265f><i class="codicon codicon-chevron-right" aria-hidden="true" data-v-1a06265f></i><div class="h4" data-v-1a06265f>LEW-BLOG</div></div><!--[-->`);
      ssrRenderList(series.value, (item, index) => {
        var _a;
        _push(`<div class="item series-item" data-v-1a06265f><div class="${ssrRenderClass([{ active: item.isShow }, "item-box"])}" data-v-1a06265f><i class="codicon codicon-chevron-right" aria-hidden="true" data-v-1a06265f></i><div class="title"${ssrRenderAttr("title", item == null ? void 0 : item.title)} data-v-1a06265f>${ssrInterpolate(item == null ? void 0 : item.title)}</div></div>`);
        if (item.article.length == 0) {
          _push(`<div style="${ssrRenderStyle(item.isShow ? null : { display: "none" })}" class="item article-item" data-v-1a06265f><div class="item-box not-box" data-v-1a06265f>\u6682\u65E0\u76F8\u5173\u6587\u7AE0</div></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<!--[-->`);
        ssrRenderList(item.article, (article, index2) => {
          _push(`<div style="${ssrRenderStyle(item.isShow ? null : { display: "none" })}" class="item article-item" data-v-1a06265f><div class="${ssrRenderClass([{ "cur-item": curId.value == article.id }, "item-box"])}" data-v-1a06265f><div class="icon-box" data-v-1a06265f><i class="${ssrRenderClass(["icon-" + (item == null ? void 0 : item.icon), "icon-seti"])}" aria-hidden="true" data-v-1a06265f></i></div><div class="title"${ssrRenderAttr("title", item == null ? void 0 : item.title)} data-v-1a06265f>${ssrInterpolate(article == null ? void 0 : article.title)}</div></div></div>`);
        });
        _push(`<!--]--><div class="article-total" data-v-1a06265f>${ssrInterpolate((_a = item == null ? void 0 : item.article) == null ? void 0 : _a.length)}</div></div>`);
      });
      _push(`<!--]--></div>`);
    };
  }
});
const _sfc_setup$9 = _sfc_main$9.setup;
_sfc_main$9.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/MenuList.vue");
  return _sfc_setup$9 ? _sfc_setup$9(props, ctx) : void 0;
};
const __nuxt_component_0$2 = /* @__PURE__ */ _export_sfc(_sfc_main$9, [["__scopeId", "data-v-1a06265f"]]);
const _sfc_main$8 = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  const _component_menu_list = __nuxt_component_0$2;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "series" }, _attrs))} data-v-75fad51b>`);
  _push(ssrRenderComponent(_component_menu_list, null, null, _parent));
  _push(`</div>`);
}
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/panel/Series.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const __nuxt_component_0$1 = /* @__PURE__ */ _export_sfc(_sfc_main$8, [["ssrRender", _sfc_ssrRender$1], ["__scopeId", "data-v-75fad51b"]]);
const _sfc_main$7 = /* @__PURE__ */ defineComponent({
  __name: "Search",
  __ssrInlineRender: true,
  setup(__props) {
    useRouter();
    let route = useRoute();
    useNuxtApp();
    let list = ref([]);
    let total = ref(0);
    let curId = ref();
    let keyword = ref("");
    watch(route, (v) => {
      const id = route.params.id;
      curId.value = id;
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "search" }, _attrs))} data-v-ccdffadc><label data-v-ccdffadc>\u641C\u7D22</label><input id="search-input"${ssrRenderAttr("value", unref(keyword))} placeholder="\u641C\u7D22\u5173\u952E\u8BCD" class="vs-input" data-v-ccdffadc>`);
      if (unref(keyword)) {
        _push(`<div class="total" data-v-ccdffadc>\u5171\u67E5\u8BE2 ${ssrInterpolate(unref(total))} \u4E2A\u7ED3\u679C</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="list" data-v-ccdffadc><!--[-->`);
      ssrRenderList(unref(list), (article, index) => {
        var _a;
        _push(`<div class="item article-item" data-v-ccdffadc><div class="${ssrRenderClass([{ "cur-item": unref(curId) == article.id }, "item-box"])}" data-v-ccdffadc><div class="icon-box" data-v-ccdffadc><i class="${ssrRenderClass(["icon-" + ((_a = article == null ? void 0 : article.series) == null ? void 0 : _a.icon), "icon-seti"])}" aria-hidden="true" data-v-ccdffadc></i></div><div class="title"${ssrRenderAttr("title", article == null ? void 0 : article.title)} data-v-ccdffadc>${ssrInterpolate(article == null ? void 0 : article.title)}</div></div></div>`);
      });
      _push(`<!--]--></div></div>`);
    };
  }
});
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/panel/Search.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const __nuxt_component_1$1 = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["__scopeId", "data-v-ccdffadc"]]);
const _sfc_main$6 = /* @__PURE__ */ defineComponent({
  __name: "Links",
  __ssrInlineRender: true,
  setup(__props) {
    let links = ref([
      {
        id: 1,
        name: "\u5C24\u96E8\u6EAA",
        url: "https://www.zhihu.com/people/evanyou",
        head_img: "https://pic4.zhimg.com/7be980a0f_xl.jpg",
        description: "\u4E00\u4E2A\u524D\u7AEF\uFF0C\u5199\u4E86\u4E00\u4E2A\u53EB Vue \u7684\u6846\u67B6\u3002",
        sort_id: 2,
        is_show: 1,
        opt: {},
        create_time: "2021-07-20 22:35:29",
        update_time: "2021-07-28 00:04:56"
      },
      {
        id: 4,
        name: "KAMOKA",
        url: "https://eee.me/",
        head_img: "https://eee.me/wp-content/uploads/2021/07/2021072110112691.jpg",
        description: "\u6700\u7F8E\u7684\u4E0D\u4E00\u5B9A\u662F\u7EC8\u70B9",
        sort_id: 2,
        is_show: 1,
        opt: {},
        create_time: "2021-07-20 22:42:06",
        update_time: "2021-07-27 11:30:55"
      },
      {
        id: 5,
        name: "\u82E5\u5FD7\u5955\u946B",
        url: "https://www.rz.sb/",
        head_img: "https://cdn.jsdelivr.net/gh/irozhi/irils-cdn/vCards/assets/img/i.svg",
        description: "\u613F\u4E16\u754C\u5B89\u5EB7\uFF0C\u613F\u4F60\u6211\u7686\u597D\uFF01",
        sort_id: 2,
        is_show: 1,
        opt: {},
        create_time: "2021-07-28 10:57:52",
        update_time: "2021-07-28 10:57:52"
      },
      {
        id: 6,
        name: "\u5317\u67AB",
        url: "https://beifeng.me/",
        head_img: "https://q2.qlogo.cn/g?b=qq&nk=41777657&s=100",
        description: "\u8FD9\u5BB6\u4F19\u5F88\u61D2\uFF0C\u6CA1\u6709\u7559\u4E0B\u4EFB\u4F55\u4E1C\u897F",
        sort_id: 2,
        is_show: 1,
        opt: {},
        create_time: "2021-07-28 11:02:15",
        update_time: "2021-07-28 11:02:15"
      },
      {
        id: 7,
        name: "Yapi",
        url: "http://yapi.smart-xwork.cn/",
        head_img: "https://kamtao-1255310647.cos.ap-chengdu.myqcloud.com/img/dbc02fb727cac1ed0722347eed507f6.png",
        description: "\u4E00\u4E2A\u795E\u5947\u7684\u63A5\u53E3\u7BA1\u7406\u5E73\u53F0",
        sort_id: 2,
        is_show: 1,
        opt: {},
        create_time: "2021-07-28 11:16:38",
        update_time: "2021-09-02 11:04:53"
      },
      {
        id: 9,
        name: "summer",
        url: "https://www.galasp.cn/",
        head_img: "https://q2.qlogo.cn/g?b=qq&nk=2770520782&s=100",
        description: "\u592A\u9633\u5F53\u7A7A\u7167\uFF0C\u82B1\u513F\u5BF9\u6211\u7B11\u3002",
        sort_id: 2,
        is_show: 1,
        opt: {},
        create_time: "2021-08-16 12:54:05",
        update_time: "2021-10-29 16:05:42"
      },
      {
        id: 10,
        name: "\u5FF5\u55B5\u7B14\u8BB0\u535A\u5BA2",
        url: "https://myo.ink/",
        head_img: "https://myo.ink/logopng/150pxxmyo.jpg",
        description: "\u4E00\u4E2A\u8BB0\u5F55\u5F71\u89C6\u751F\u6DAF\u4E2D\u7684\u7B14\u8BB0\u535A\u5BA2",
        sort_id: 2,
        is_show: 1,
        opt: {},
        create_time: "2021-11-05 15:40:38",
        update_time: "2021-11-05 15:40:38"
      },
      {
        id: 11,
        name: "\u9752\u627E\xB7\u751F\u6D3B",
        url: "https://www.linguang.me/",
        head_img: "https://cravatar.cn/avatar/ca19c9e504c3b23449756ab1be1508a9",
        description: "\u4E91\u5929\u6536\u590F\u8272\uFF0C\u6728\u53F6\u52A8\u79CB\u58F0",
        sort_id: 2,
        is_show: 1,
        opt: {},
        create_time: "2021-11-05 15:51:22",
        update_time: "2021-11-05 15:51:22"
      },
      {
        id: 14,
        name: "\u94F6\u6CB3\u5C0F\u5F90",
        url: "https://blog.hasaik.com",
        head_img: "https://cdn.jsdelivr.net/gh/XuxuGood/simple-blog-cdn@main/images/site-img/avatar.jpeg",
        description: "\u535A\u89C2\u800C\u7EA6\u53D6\uFF0C\u539A\u79EF\u800C\u8584\u53D1",
        sort_id: 2,
        is_show: 1,
        opt: {},
        create_time: "2021-12-14 17:32:56",
        update_time: "2021-12-14 17:32:56"
      }
    ]);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_link = __nuxt_component_0$2$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "links" }, _attrs))} data-v-5f1fc0ad><div class="title" data-v-5f1fc0ad>\u53CB\u60C5\u94FE\u63A5</div><div class="list" data-v-5f1fc0ad><!--[-->`);
      ssrRenderList(unref(links), (item, index) => {
        _push(ssrRenderComponent(_component_nuxt_link, {
          to: item.url,
          target: "_blank",
          key: index,
          class: "item"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<img class="avatar"${ssrRenderAttr("src", item.head_img)} alt="" srcset="" data-v-5f1fc0ad${_scopeId}><div class="info" data-v-5f1fc0ad${_scopeId}><div class="blog" data-v-5f1fc0ad${_scopeId}>${ssrInterpolate(item.name)}</div><div class="url" data-v-5f1fc0ad${_scopeId}>${ssrInterpolate(item.description)}</div></div>`);
            } else {
              return [
                createVNode("img", {
                  class: "avatar",
                  src: item.head_img,
                  alt: "",
                  srcset: ""
                }, null, 8, ["src"]),
                createVNode("div", { class: "info" }, [
                  createVNode("div", { class: "blog" }, toDisplayString(item.name), 1),
                  createVNode("div", { class: "url" }, toDisplayString(item.description), 1)
                ])
              ];
            }
          }),
          _: 2
        }, _parent));
      });
      _push(`<!--]--></div></div>`);
    };
  }
});
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/panel/Links.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["__scopeId", "data-v-5f1fc0ad"]]);
const _sfc_main$5 = {
  __name: "Blogger",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { $api } = useNuxtApp();
    let blogger = ref({});
    blogger.value = ([__temp, __restore] = withAsyncContext(() => $api.get("/blog/app/blogger")), __temp = await __temp, __restore(), __temp).data;
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "blogger" }, _attrs))} data-v-8070db53><div class="base" data-v-8070db53><img class="avatar"${ssrRenderAttr("src", (_a = unref(blogger)) == null ? void 0 : _a.avatar)} alt="" srcset="" data-v-8070db53><div class="nickname" data-v-8070db53>${ssrInterpolate((_b = unref(blogger)) == null ? void 0 : _b.nickname)} <i class="codicon codicon-verified-filled" data-v-8070db53></i></div></div><div class="description" data-v-8070db53>${ssrInterpolate((_c = unref(blogger)) == null ? void 0 : _c.description)}</div><div class="info" data-v-8070db53><div class="item" data-v-8070db53> \u751F\u4E8E <span class="value" data-v-8070db53>${ssrInterpolate(unref(dayjs)((_d = unref(blogger)) == null ? void 0 : _d.birthday).format("YYYY"))}</span></div><div class="item" data-v-8070db53> \u5C31\u804C\u4E8E <span class="value" data-v-8070db53>${ssrInterpolate((_e = unref(blogger)) == null ? void 0 : _e.company)}</span></div><div class="item" data-v-8070db53> \u90AE\u7BB1 <span class="value" data-v-8070db53>${ssrInterpolate((_f = unref(blogger)) == null ? void 0 : _f.email)}</span></div></div></div>`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/panel/Blogger.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["__scopeId", "data-v-8070db53"]]);
const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  __name: "Setting",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "setting" }, _attrs))} data-v-9fadec2e><div class="title" data-v-9fadec2e>\u8BBE\u7F6E\u9762\u677F</div><div class="main" data-v-9fadec2e><div class="vs-button" data-v-9fadec2e>\u9000\u51FA\u767B\u9646</div></div></div>`);
    };
  }
});
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/panel/Setting.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_4 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["__scopeId", "data-v-9fadec2e"]]);
const _sfc_main$3 = {
  __name: "User",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "user" }, _attrs))} data-v-341d46d9><div class="vs-button" data-v-341d46d9> \u767B\u5F55 </div></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/panel/User.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_5 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-341d46d9"]]);
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "TheSidebar",
  __ssrInlineRender: true,
  setup(__props) {
    let mode = ref("series");
    let modeList = ref({
      top: [
        {
          mode: "series",
          icon: "files"
        },
        {
          mode: "search",
          icon: "search"
        },
        {
          mode: "links",
          icon: "source-control"
        },
        {
          mode: "github",
          icon: "github",
          link: "https://github.com/lewkamtao"
        }
      ],
      bottom: [
        {
          mode: "blogger",
          icon: "account"
        },
        {
          mode: "setting",
          icon: "settings-gear"
        }
      ]
    });
    const menuActive = useMenuActive();
    watch(menuActive, (v) => {
      let list = [...modeList.value.top, ...modeList.value.bottom];
      changeMode(list.find((e) => e.mode == v));
    });
    const changeMode = (item) => {
      if (item == null ? void 0 : item.link) {
        window.open(item.link, "_blank");
      } else {
        mode.value = item.mode;
      }
      if (item.mode == "search") {
        nextTick(() => {
          document.getElementById("search-input").focus();
        });
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_panel_series = __nuxt_component_0$1;
      const _component_panel_search = __nuxt_component_1$1;
      const _component_panel_links = __nuxt_component_2;
      const _component_panel_blogger = __nuxt_component_3;
      const _component_panel_setting = __nuxt_component_4;
      const _component_panel_user = __nuxt_component_5;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "sidebar" }, _attrs))} data-v-1b50bed0><div class="nav" data-v-1b50bed0><div class="top" data-v-1b50bed0><!--[-->`);
      ssrRenderList(unref(modeList).top, (item, index) => {
        _push(`<div class="${ssrRenderClass([unref(mode) == item.mode ? "active" : "", "item"])}" data-v-1b50bed0><i class="${ssrRenderClass([`codicon-${item.icon}`, "codicon"])}" aria-hidden="true" data-v-1b50bed0></i>`);
        if (item.mode == "links") {
          _push(`<div class="vs-badge" data-v-1b50bed0>9</div>`);
        } else {
          _push(`<!---->`);
        }
        if (item.mode == "comment") {
          _push(`<div class="vs-badge" data-v-1b50bed0>2</div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      });
      _push(`<!--]--></div><div class="bottom" data-v-1b50bed0><!--[-->`);
      ssrRenderList(unref(modeList).bottom, (item, index) => {
        _push(`<div class="${ssrRenderClass([{ active: unref(mode) == item.mode }, "item"])}" data-v-1b50bed0><i class="${ssrRenderClass([`codicon-${item.icon}`, "codicon"])}" aria-hidden="true" data-v-1b50bed0></i></div>`);
      });
      _push(`<!--]--></div></div><div class="sidebar-main" data-v-1b50bed0>`);
      _push(ssrRenderComponent(_component_panel_series, {
        style: unref(mode) == "series" ? null : { display: "none" }
      }, null, _parent));
      _push(ssrRenderComponent(_component_panel_search, {
        style: unref(mode) == "search" ? null : { display: "none" }
      }, null, _parent));
      _push(ssrRenderComponent(_component_panel_links, {
        style: unref(mode) == "links" ? null : { display: "none" }
      }, null, _parent));
      _push(ssrRenderComponent(_component_panel_blogger, {
        style: unref(mode) == "blogger" ? null : { display: "none" }
      }, null, _parent));
      _push(ssrRenderComponent(_component_panel_setting, {
        style: unref(mode) == "setting" ? null : { display: "none" }
      }, null, _parent));
      _push(ssrRenderComponent(_component_panel_user, {
        style: unref(mode) == "user" ? null : { display: "none" }
      }, null, _parent));
      _push(`</div></div>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/TheSidebar.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-1b50bed0"]]);
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "TheFooter",
  __ssrInlineRender: true,
  setup(__props) {
    const blog = useBlog();
    const route = useRoute();
    const { language } = useNavigatorLanguage();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "footer" }, _attrs))} data-v-f6cd5e4e><div data-v-f6cd5e4e><span data-v-f6cd5e4e> Copyright (c) 2021-present, Kamtao (To) Lew </span><span data-v-f6cd5e4e> Inspired by Visual Studio Code </span><a target="_blank" href="https://beian.miit.gov.cn/" data-v-f6cd5e4e>\u7CA4ICP\u590718056223\u53F7</a></div><div data-v-f6cd5e4e><span data-v-f6cd5e4e> Current version 1.12.0 </span><span data-v-f6cd5e4e> PATH ${ssrInterpolate(unref(route).path)}</span><span data-v-f6cd5e4e> Language ${ssrInterpolate(unref(language))}</span><span data-v-f6cd5e4e> Series ${ssrInterpolate(unref(blog).seriesTotal)}</span><span data-v-f6cd5e4e> Article ${ssrInterpolate(unref(blog).articleTotal)}</span></div></div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/TheFooter.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-f6cd5e4e"]]);
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_TheSidebar = __nuxt_component_0;
  const _component_TheFooter = __nuxt_component_1;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "lew" }, _attrs))} data-v-95b6d713><div class="main" data-v-95b6d713>`);
  _push(ssrRenderComponent(_component_TheSidebar, null, null, _parent));
  _push(`<div class="wrapper" data-v-95b6d713>`);
  ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
  _push(`</div></div>`);
  _push(ssrRenderComponent(_component_TheFooter, null, null, _parent));
  _push(`</div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/default.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _default = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__scopeId", "data-v-95b6d713"]]);

export { _default as default };
//# sourceMappingURL=default.00eba624.mjs.map
